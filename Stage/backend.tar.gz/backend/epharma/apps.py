from django.apps import AppConfig


class EpharmaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'epharma'
